/** SEO para o projeto Astro LauraDevCode. Sem endereço físico inventado. */
export const SITE_URL = 'https://lauradevcode.vercel.app';
export const BUSINESS_NAME = 'LauraDevCode';
export const CONTACT_PHONE = '+5561998213684';

const pages: Record<string, { title: string; description: string; service?: string }> = {
  '/': {
    title: 'Estrutura Digital para Negócios em Brasília | LauraDevCode',
    description: 'Google Meu Negócio, Google Ads, Meta Ads, sites, sistemas e automações para negócios locais em Brasília e empresas online em todo o Brasil.'
  },
  '/portfolio/': {
    title: 'Projetos e Soluções Digitais | LauraDevCode',
    description: 'Veja projetos de sites e landing pages da LauraDevCode para diferentes segmentos, com capturas e links para trabalhos publicados.'
  },
  '/sobre/': {
    title: 'Sobre | Tecnologia e Estratégia para Negócios | LauraDevCode',
    description: 'Conheça a LauraDevCode, marca de uma desenvolvedora full stack com experiência em sites, sistemas web, SaaS e estratégia digital para empresas.'
  },
  '/contato/': {
    title: 'Contato e Orçamento de Soluções Digitais | LauraDevCode',
    description: 'Solicite orçamento para Google Meu Negócio, Google Ads, Meta Ads, criação de sites, sistemas ou automações. Atendimento em Brasília e online.'
  },
  '/servicos/google-meu-negocio/': {
    title: 'Otimização do Google Meu Negócio em Brasília | LauraDevCode',
    description: 'Organização e otimização do Perfil da Empresa no Google para negócios locais em Brasília: serviços, categorias, fotos e presença no Google Maps.',
    service: 'Otimização do Perfil da Empresa no Google'
  },
  '/servicos/google-ads/': {
    title: 'Gestão de Google Ads em Brasília | LauraDevCode',
    description: 'Planejamento e gestão de campanhas no Google Ads para empresas em Brasília e negócios online, com foco em buscas relevantes e acompanhamento de conversões.',
    service: 'Gestão de campanhas Google Ads'
  },
  '/servicos/meta-ads/': {
    title: 'Gestão de Meta Ads em Brasília | LauraDevCode',
    description: 'Campanhas no Instagram e Facebook para alcançar públicos estratégicos, gerar oportunidades e acompanhar o desempenho dos anúncios.',
    service: 'Gestão de campanhas Meta Ads'
  },
  '/servicos/criacao-de-sites/': {
    title: 'Criação de Sites e Landing Pages | LauraDevCode',
    description: 'Sites institucionais e landing pages responsivos, com estrutura clara, experiência de navegação e otimização técnica para empresas.',
    service: 'Criação de sites e landing pages'
  },
  '/servicos/sistemas-web/': {
    title: 'Desenvolvimento de Sistemas Web e SaaS | LauraDevCode',
    description: 'Desenvolvimento de sistemas web personalizados, dashboards, automações e plataformas SaaS sob medida para operações e produtos digitais.',
    service: 'Desenvolvimento de sistemas web e SaaS'
  },
  '/servicos/lojas-virtuais/': {
    title: 'Criação de Lojas Virtuais e E-commerce | LauraDevCode',
    description: 'Criação de lojas virtuais e e-commerce com catálogo de produtos, jornada de compra organizada e integrações comerciais.',
    service: 'Criação de lojas virtuais'
  },
  '/servicos/trafego-pago/': {
    title: 'Gestão de Google Ads e Meta Ads | LauraDevCode',
    description: 'Gestão de tráfego pago para empresas: planejamento de Google Ads e Meta Ads, mensuração de conversões e otimização de campanhas.',
    service: 'Gestão de tráfego pago'
  }
};

function normalizePath(path: string) {
  const clean = path.replace(/\/+/g, '/');
  return clean.endsWith('/') ? clean : `${clean}/`;
}
export function getSeoForPath(path: string) {
  return pages[normalizePath(path)] ?? pages['/'];
}
export const PUBLIC_PAGES = Object.keys(pages);

export function makeStructuredData(path: string, canonical: string, title: string, description: string) {
  const p = normalizePath(path);
  const company = {
    '@type': 'Organization',
    '@id': `${SITE_URL}/#organizacao`,
    name: BUSINESS_NAME,
    url: SITE_URL,
    description: 'Estratégia e estrutura digital para negócios: Perfil da Empresa no Google, anúncios, sites, sistemas e automações.',
    areaServed: [{ '@type': 'AdministrativeArea', name: 'Distrito Federal' }, { '@type': 'Country', name: 'Brasil' }],
    contactPoint: { '@type': 'ContactPoint', telephone: CONTACT_PHONE, contactType: 'sales', availableLanguage: 'Portuguese' },
  };
  const website = {
    '@type': 'WebSite', '@id': `${SITE_URL}/#site`, name: BUSINESS_NAME,
    url: SITE_URL, inLanguage: 'pt-BR', publisher: { '@id': `${SITE_URL}/#organizacao` }
  };
  const webpage = {
    '@type': 'WebPage', '@id': `${canonical}#pagina`, url: canonical,
    name: title, description, inLanguage: 'pt-BR',
    isPartOf: { '@id': `${SITE_URL}/#site` }, about: { '@id': `${SITE_URL}/#organizacao` }
  };
  const nodes: Record<string, unknown>[] = [company, website, webpage];
  const service = pages[p]?.service;
  if (service) nodes.push({
    '@type': 'Service', name: service, description,
    provider: { '@id': `${SITE_URL}/#organizacao` },
    serviceType: service,
    areaServed: [{ '@type': 'AdministrativeArea', name: 'Distrito Federal' }, { '@type': 'Country', name: 'Brasil' }],
    url: canonical
  });
  if (p !== '/') nodes.push({
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Início', item: `${SITE_URL}/` },
      { '@type': 'ListItem', position: 2, name: service || title.split(' | ')[0], item: canonical }
    ]
  });
  return { '@context': 'https://schema.org', '@graph': nodes };
}
