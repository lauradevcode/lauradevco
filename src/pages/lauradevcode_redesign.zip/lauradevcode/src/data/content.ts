export const services = [
 {id:'google-meu-negocio',number:'01',title:'Google Meu Negócio',eyebrow:'Presença local',summary:'Organização e otimização do Perfil da Empresa no Google para facilitar a descoberta do seu negócio na Pesquisa e no Maps.',description:'Categorias, serviços, apresentação, fotos e boas práticas para manter seu perfil claro, atualizado e útil para clientes da região.',items:['Revisão do perfil','Categorias e serviços','Fotos e conteúdo','Orientação para avaliações legítimas']},
 {id:'google-ads',number:'02',title:'Google Ads',eyebrow:'Busca e aquisição',summary:'Campanhas para alcançar pessoas que já procuram soluções como as que sua empresa oferece.',description:'Planejamento, configuração e otimização de campanhas de pesquisa, com mensuração de contatos e análise contínua.',items:['Pesquisa e intenção de busca','Configuração de campanhas','Mensuração de conversões','Acompanhamento e otimização']},
 {id:'meta-ads',number:'03',title:'Meta Ads',eyebrow:'Alcance e demanda',summary:'Anúncios no Instagram e Facebook para apresentar suas ofertas a públicos relevantes.',description:'Estratégia de públicos, criativos e acompanhamento dos indicadores de campanhas no ecossistema Meta.',items:['Planejamento de públicos','Campanhas Instagram e Facebook','Teste de criativos','Análise de desempenho']},
 {id:'criacao-de-sites',number:'04',title:'Sites e landing pages',eyebrow:'Presença e conversão',summary:'Sites institucionais e páginas de campanha com estrutura clara, desempenho e experiência responsiva.',description:'Do primeiro contato à solicitação de orçamento, cada página é planejada para apresentar sua empresa com clareza e transformar interesse em oportunidade.',items:['Sites institucionais','Landing pages','Redesign e manutenção','Otimização técnica e SEO']},
 {id:'sistemas-web',number:'05',title:'Sistemas web e SaaS',eyebrow:'Produto e operação',summary:'Sistemas personalizados, painéis de gestão e produtos digitais desenvolvidos para processos reais.',description:'Planejamento, interface e desenvolvimento de soluções sob medida para simplificar operações e criar novos produtos digitais.',items:['Sistemas administrativos','Dashboards','Plataformas SaaS','Integrações e automações']},
 {id:'lojas-virtuais',number:'06',title:'Lojas virtuais',eyebrow:'Comércio digital',summary:'Experiências de compra organizadas, rápidas e preparadas para vender produtos pela internet.',description:'Estruturação de catálogos, páginas de produto e jornadas de compra para marcas que desejam operar no digital.',items:['E-commerce','Catálogo de produtos','Integrações comerciais','Experiência de compra']},
 {id:'trafego-pago',number:'07',title:'Gestão de tráfego pago',eyebrow:'Aquisição de clientes',summary:'Campanhas de Google Ads e Meta Ads com acompanhamento de métricas e foco em oportunidades comerciais.',description:'Planejamento, implantação e otimização de campanhas alinhadas à oferta, ao público e ao orçamento do negócio.',items:['Google Ads','Meta Ads','Mensuração de conversões','Otimização de campanhas']},
];
// Portfólio real: cada projeto representa um trabalho, não um nicho exclusivo.
// Coloque os PNGs em public/images/projetos/ com os nomes abaixo.
// A home mostra apenas os 3 primeiros projetos; /portfolio mostra TODOS.
// Para incluir novos, acrescente objetos ao fim do array mantendo o mesmo formato.
// Botão "Visualizar site ao vivo" aparece apenas para endereço HTTPS confirmado.
// Se não houver link, mantenha url: ''.
// Descreva somente entregas comprovadas; URLs são opcionais.
export const projects = [
  {
    title: 'Wilson Alves Advocacia',
    category: 'Advocacia · Site institucional',
    description: 'Projeto desenvolvido para apresentação digital de um escritório de advocacia. Veja a captura ampliada para conhecer a interface e o trabalho visual.',
    scope: 'Projeto web para o segmento jurídico.',
    image: '/images/projetos/wilson-alves-advocacia.png',
    url: 'https://wilsonalvesadv.com.br/' // Site ao vivo ainda não verificado; mantém o botão oculto.
  },
  {
    title: 'Daiane Alcantara',
    category: 'Psicologia · Landing page',
    description: 'Projeto de presença digital para uma profissional de psicologia. A captura mostra a composição visual e a apresentação do serviço.',
    scope: 'Projeto web para profissional da área de psicologia.',
    image: '/images/projetos/daiane-alcantara.png',
    url: 'https://www.daianealcantara.com.br/'
  },
  {
    title: 'Luan Pereira',
    category: 'Personal trainer · Site profissional',
    description: 'Projeto digital para apresentação de serviços de treinamento físico. Explore a captura para visualizar o trabalho desenvolvido.',
    scope: 'Projeto web para profissional de treinamento físico.',
    image: '/images/projetos/luan-pereira.png',
    url: 'https://lp-luan-personal.vercel.app/' // Site ao vivo ainda não verificado; mantém o botão oculto.
  }
];
